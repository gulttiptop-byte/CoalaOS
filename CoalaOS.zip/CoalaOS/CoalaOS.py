import sys
import os
import io
import contextlib
import requests
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *

# Попытка импорта браузерного движка
try:
    from PyQt5.QtWebEngineWidgets import QWebEngineView
except ImportError:
    QWebEngineView = None

# Константы системы
API_KEY = "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"
MODEL_ID = "arcee-ai/trinity-large-preview:free"
APPS_DIR = "apps"

if not os.path.exists(APPS_DIR):
    os.makedirs(APPS_DIR)

# --- БАЗОВЫЕ СТИЛИ ---
QSS = """
QMainWindow { background: #000; }
QMdiSubWindow {
    background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #2b2b2b, stop:1 #1a1a1a);
    border: 1px solid #444;
    border-radius: 8px;
}
QTextEdit, QLineEdit {
    background: rgba(0, 0, 0, 150);
    color: #00ffcc;
    border: 1px solid #333;
    font-family: 'Consolas';
}
QListWidget {
    background: rgba(20, 20, 20, 200);
    color: white;
    border: none;
    outline: none;
}
QPushButton#StartBtn {
    background: #0078d4;
    border-radius: 10px;
}
QPushButton#StartBtn:hover { background: #008aff; }
"""

# --- КЛАСС ИКОНКИ ---
class DesktopIcon(QWidget):
    def __init__(self, name, icon_prefix, callback, is_file=False, ext=None, parent=None):
        super().__init__(parent)
        self.setFixedSize(110, 130)
        self.callback = callback
        self.dragging = False
        
        layout = QVBoxLayout(self)
        self.btn = QPushButton()
        self.btn.setFixedSize(70, 70)
        
        if is_file:
            style = "font-size: 30px; border-radius: 12px; border: 1px solid #555;"
            if ext == ".coef":
                self.btn.setText("⚙️")
                self.btn.setStyleSheet(style + "background: rgba(0, 255, 180, 40);")
            else:
                self.btn.setText("📄")
                self.btn.setStyleSheet(style + "background: rgba(255, 255, 255, 30);")
        else:
            path = next((icon_prefix + e for e in ['.png', '.jpg'] if os.path.exists(icon_prefix + e)), None)
            if path:
                self.btn.setIcon(QIcon(path))
                self.btn.setIconSize(QSize(45, 45))
                self.btn.setStyleSheet("background: rgba(255,255,255,15); border: none; border-radius: 15px;")
            else:
                self.btn.setText(name[0])
                self.btn.setStyleSheet("background: #444; color: white; border-radius: 15px; font-size: 20px;")

        self.btn.clicked.connect(self.callback)
        
        self.lbl = QLabel(name)
        self.lbl.setAlignment(Qt.AlignCenter)
        self.lbl.setStyleSheet("color: white; font-weight: bold; text-shadow: 2px 2px 3px black;")
        self.lbl.setWordWrap(True)
        
        layout.addWidget(self.btn, alignment=Qt.AlignCenter)
        layout.addWidget(self.lbl)

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self.dragging = True; self.offset = e.pos(); self.raise_()
    def mouseMoveEvent(self, e):
        if self.dragging: self.move(self.mapToParent(e.pos() - self.offset))
    def mouseReleaseEvent(self, e):
        if e.button() == Qt.LeftButton:
            self.dragging = False
            self.move(round(self.x()/110)*110, round(self.y()/130)*130)

# --- ОС ---
class CoalaOS(QMainWindow):
    def __init__(self):
        super().__init__()
        self.showFullScreen()
        self.setStyleSheet(QSS)
        
        # Контейнер рабочего стола
        self.root = QWidget()
        self.setCentralWidget(self.root)
        self.root_layout = QVBoxLayout(self.root)
        self.root_layout.setContentsMargins(0,0,0,0)
        self.root_layout.setSpacing(0)
        
        # Фоновое изображение
        self.wallpaper = QLabel(self.root)
        self.wallpaper.setScaledContents(True)
        self.wallpaper.setGeometry(0, 0, self.width(), self.height())
        self.set_default_wallpaper()
        
        # MDI Area (Окна)
        self.desktop = QMdiArea(self.root)
        self.desktop.setBackground(Qt.transparent)
        self.desktop.setContextMenuPolicy(Qt.CustomContextMenu)
        self.desktop.customContextMenuRequested.connect(self.desktop_menu)
        
        # Панель задач
        self.taskbar = QFrame()
        self.taskbar.setFixedHeight(60)
        self.taskbar.setStyleSheet("background: rgba(10, 10, 10, 220); border-top: 1px solid #333;")
        tb_layout = QHBoxLayout(self.taskbar)
        
        self.start_btn = QPushButton()
        self.start_btn.setObjectName("StartBtn")
        self.start_btn.setFixedSize(60, 45)
        if os.path.exists("v.png"):
            self.start_btn.setIcon(QIcon("v.png"))
            self.start_btn.setIconSize(QSize(30, 30))
        self.start_btn.clicked.connect(self.toggle_start)
        
        self.clock = QLabel()
        self.clock.setStyleSheet("color: #00ffcc; font-family: 'Consolas'; font-size: 16px; font-weight: bold; margin-right: 20px;")
        
        tb_layout.addWidget(self.start_btn); tb_layout.addStretch(); tb_layout.addWidget(self.clock)
        
        self.root_layout.addWidget(self.desktop)
        self.root_layout.addWidget(self.taskbar)
        
        # Меню Пуск
        self.sm = QFrame(self.root)
        self.sm.setGeometry(10, self.height()-650, 320, 580)
        self.sm.setStyleSheet("background: rgba(25, 25, 25, 250); border: 1px solid #444; border-radius: 15px;")
        self.sm_layout = QVBoxLayout(self.sm)
        self.sm.hide()
        
        self.init_desktop()
        
        timer = QTimer(self)
        timer.timeout.connect(lambda: self.clock.setText(QTime.currentTime().toString("HH:mm:ss")))
        timer.start(1000)

    def set_default_wallpaper(self):
        # Если нет своих обоев, создаем темный градиент
        pix = QPixmap(self.width(), self.height())
        grad = QLinearGradient(0, 0, self.width(), self.height())
        grad.setColorAt(0, QColor(20, 20, 25))
        grad.setColorAt(1, QColor(40, 45, 60))
        painter = QPainter(pix)
        painter.fillRect(pix.rect(), grad)
        painter.end()
        self.wallpaper.setPixmap(pix)

    def change_wallpaper(self):
        path, _ = QFileDialog.getOpenFileName(self, "Выбрать обои", "", "Images (*.png *.jpg *.jpeg)")
        if path:
            self.wallpaper.setPixmap(QPixmap(path))

    def init_desktop(self):
        for item in self.desktop.findChildren(DesktopIcon): item.deleteLater()
        
        # Системные иконки
        sys_apps = [
            ("Проводник", "y", self.open_explorer),
            ("Браузер", "l", self.open_browser),
            ("AI Chat", "i", self.open_ai),
            ("Блокнот", "m", lambda: self.win("Блокнот", QTextEdit())),
            ("IDE", "v", self.open_ide),
            ("Терминал", "l", lambda: self.win("Terminal", QTextEdit("Kernel v9.0 Online...")))
        ]
        
        for i, (name, icon, func) in enumerate(sys_apps):
            it = DesktopIcon(name, icon, func, parent=self.desktop)
            it.move(20, 20 + (i * 130)); it.show()

        # Файлы пользователей (ФИКС БАГА FALSE)
        x_p, y_p = 140, 20
        for f_name in os.listdir(APPS_DIR):
            ext = os.path.splitext(f_name)[1]
            if ext in [".coef", ".coif"]:
                # Используем вспомогательную функцию для захвата имени файла
                callback = self.create_file_callback(f_name)
                it = DesktopIcon(f_name, "", callback, is_file=True, ext=ext, parent=self.desktop)
                it.move(x_p, y_p); it.show()
                y_p += 130
                if y_p > self.height() - 250: y_p = 20; x_p += 120

    def create_file_callback(self, name):
        return lambda: self.open_custom_file(name)

    def win(self, title, widget, w=900, h=600):
        sub = QMdiSubWindow()
        sub.setWidget(widget)
        sub.setWindowTitle(title)
        self.desktop.addSubWindow(sub)
        sub.resize(w, h); sub.show()
        return sub

    def desktop_menu(self, pos):
        m = QMenu(self)
        m.addAction("🔄 Обновить").triggered.connect(self.init_desktop)
        m.addAction("🖼 Сменить обои").triggered.connect(self.change_wallpaper)
        m.addAction("🛠 IDE Редактор").triggered.connect(self.open_ide)
        m.exec_(self.desktop.mapToGlobal(pos))

    # --- ПРИЛОЖЕНИЯ ---
    def open_ide(self):
        w = QWidget(); l = QVBoxLayout(w)
        btn = QPushButton("💾 СОХРАНИТЬ В APPS")
        btn.setStyleSheet("background: #0078d4; color: white; padding: 10px; font-weight: bold;")
        edit = QTextEdit(); edit.setPlaceholderText("Код или текст...")
        l.addWidget(btn); l.addWidget(edit)
        def save():
            menu = QMenu()
            c1 = menu.addAction("Код (.coef)"); c2 = menu.addAction("Инфо (.coif)")
            res = menu.exec_(btn.mapToGlobal(QPoint(0, 40)))
            ext = ".coef" if res == c1 else ".coif" if res == c2 else None
            if ext:
                name, ok = QInputDialog.getText(self, "Save", "Имя:")
                if ok and name:
                    with open(f"{APPS_DIR}/{name}{ext}", "w", encoding="utf-8") as f:
                        f.write(edit.toPlainText())
                    self.init_desktop()
        btn.clicked.connect(save)
        self.win("Coala IDE v9.0", w)

    def open_custom_file(self, filename):
        if not isinstance(filename, str): return # Жёсткая проверка типа
        path = os.path.join(APPS_DIR, filename)
        if not os.path.exists(path): return
        
        with open(path, "r", encoding="utf-8") as f:
            data = f.read()
            
        if filename.endswith(".coef"):
            out = QTextEdit(); self.win(f"Console: {filename}", out)
            f_io = io.StringIO()
            with contextlib.redirect_stdout(f_io):
                try: exec(data)
                except Exception as e: print(f"Runtime Error: {e}")
            out.setText(f_io.getvalue())
        else:
            view = QTextEdit(); view.setText(data); self.win(f"Note: {filename}", view)

    def open_explorer(self):
        lw = QListWidget()
        for f in os.listdir(APPS_DIR): lw.addItem(f)
        lw.itemDoubleClicked.connect(lambda it: self.open_custom_file(it.text()))
        self.win("Explorer", lw, 500, 400)

    def open_browser(self):
        if QWebEngineView:
            web = QWebEngineView(); web.load(QUrl("https://www.google.com"))
            self.win("Browser", web)
        else: QMessageBox.warning(self, "Error", "PyQtWebEngine missing")

    def open_ai(self):
        w = QWidget(); l = QVBoxLayout(w); out = QTextEdit(); out.setReadOnly(True)
        inp = QLineEdit(); inp.setPlaceholderText("Спроси AI...")
        def ask():
            t = inp.text(); out.append(f"<b>Вы:</b> {t}"); inp.clear()
            try:
                r = requests.post("https://openrouter.ai/api/v1/chat/completions",
                    headers={"Authorization": f"Bearer {API_KEY}"},
                    json={"model": MODEL_ID, "messages": [{"role": "user", "content": t}]})
                ans = r.json()['choices'][0]['message']['content']
                out.append(f"<span style='color:#00ffcc;'>AI: {ans}</span><br>")
            except: out.append("<i>Ошибка соединения...</i>")
        inp.returnPressed.connect(ask); l.addWidget(out); l.addWidget(inp); self.win("AI Assistant", w)

    def toggle_start(self):
        if self.sm.isHidden():
            for i in reversed(range(self.sm_layout.count())):
                it = self.sm_layout.itemAt(i).widget()
                if it: it.setParent(None)
            
            apps = ["Проводник", "Браузер", "AI Chat", "IDE", "Блокнот", "Терминал", "Персонализация"]
            for a in apps:
                btn = QPushButton(f"  📂 {a}")
                btn.setStyleSheet("color: white; text-align: left; padding: 12px; border: none; font-size: 14px;")
                btn.clicked.connect(lambda ch, n=a: self.run_app(n))
                self.sm_layout.addWidget(btn)
            
            self.sm_layout.addStretch()
            off = QPushButton("🔴 SHUTDOWN"); off.setStyleSheet("background: #500; color: white; padding: 10px;")
            off.clicked.connect(self.close); self.sm_layout.addWidget(off)
            self.sm.show(); self.sm.raise_()
        else:
            self.sm.hide()

    def run_app(self, name):
        self.sm.hide()
        if name == "Проводник": self.open_explorer()
        elif name == "Браузер": self.open_browser()
        elif name == "AI Chat": self.open_ai()
        elif name == "IDE": self.open_ide()
        elif name == "Блокнот": self.win("Notepad", QTextEdit())
        elif name == "Терминал": self.win("Terminal", QTextEdit("Ready..."))
        elif name == "Персонализация": self.change_wallpaper()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    coala = CoalaOS()
    coala.show()
    sys.exit(app.exec_())